Oligopoly��

This is not only personal use but also commercial use for everyone.

�� Hyun S. Choi 2019
https://www.behance.net/IbrushU